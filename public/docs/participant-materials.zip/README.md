# LIGHT UP × TUM Blockchain Club Hackathon

How would you choose a crypto exchange, a software wallet or a tax tool if you could see exactly how every rating was earned?

On Saturday, 28 November 2026, 22 participants form teams of two or three. Three tracks each take on a whole LIGHT UP comparison: what to rate, how to rate it and how to test it. People test what only people can judge, such as how easy an app is to use. Agents collect and check the public facts. Every track ends with something LIGHT UP can use after the event. Andi from LIGHT UP introduces the tracks with real examples and supports the teams.

## Before the event

- Bring your laptop. You can use any AI tools you like. TBC has shared setup information with participants.
- Read the three track briefs and the [rating matrices](matrices/). For context, each brief links LIGHT UP’s latest comparison video (German). The matrices are more current than the videos.
- If you want to open test accounts in the exchange track, bring your smartphone and an ID document. For the optional cost test you need €10 of your own money and a way to deposit it. Taking part without an account is fine.

## Choose your track

| Track brief | Guiding question | What LIGHT UP gets out of it |
|---|---|---|
| [Crypto Exchange Comparison](tracks/01-exchange.md) | How can we improve the crypto exchange comparison as a whole? | Revised criteria for the categories you choose, a usability test of five exchanges with real sign-ups and timings, a €10 cost test, and agents that collect public facts |
| [Crypto Wallet Comparison](tracks/02-wallet.md) | What would a good software wallet comparison look like if we built it from scratch? | A provider list, criteria, scoring rules and weights for a new comparison, tried on three wallets |
| [Crypto Taxtool Comparison](tracks/03-taxtool.md) | How can we improve the crypto tax tool comparison as a whole, including how it rates prices? | Revised criteria, a test of five tools with a shared [sample dataset](data/taxtool-sample/) and the basis for a cost calculator |

Teams form on site. Choose a track and use one of its suggested focuses below, or explore another idea for that comparison. Multiple teams can choose the same focus.

| Track | Focus A | Focus B | Focus C |
|---|---|---|---|
| Exchanges | Hands-on test: usability and costs | Security | Data agent |
| Wallets | Security | Usability, features and pilot | Scope, provider list and data agent |
| Tax tools | Costs and calculator | Sample dataset test | Data agent |

Choose a team name and include your track and chosen topic in your submission.

Each brief shows the matrix it starts from. The full matrices with every scoring rule are in [matrices/](matrices/). At LIGHT UP, the two of us cross-check each other's findings and use community feedback when reviewing weights, so a proposal from this hackathon goes to a community poll before it changes the matrix. Every exchange in the comparison is tested with €1,000 of real money, from deposit through a bitcoin purchase to withdrawal to a personal wallet. [Read the methodology and download the rating matrices (German).](https://lightupkryptos.de/so-testen-wir/)

## The brief for every team

Start from the matrix in your brief. Define each scoring rule before you look at any product, then try it on two or three products. Show the current and proposed approach side by side. Record how long the check took and what would trigger the next one. A spreadsheet, sketch, short script, prototype or worked example is welcome.

A proposal can add or remove a criterion or a category, change its scoring or points, or change how the result appears to readers. [Submission template](templates/comparison.md)

## Working with agents

People test, agents collect. Use your agents for public facts: fee pages, licence registers, documentation, app store data, audits. Your own impressions from hands-on tests go into the agent as a prompt you write yourself, using the [hands-on test log](templates/hands-on-test.md).

Agents never get access to your accounts. Do not give them logins, passwords, verification codes, ID documents, API keys, seed phrases or screenshots that show personal data. Blur personal data before you share any screenshot with your team.

## Submission and evaluation

**Submit your project and your pitch presentation by 17:00 CET on Saturday, 28 November.** Submit the public repository URL through the team portal and put your pitch deck on its default branch. Use the [submission template](templates/comparison.md) for your write-up.

| Saturday (CET) | Activity |
|---|---|
| 11:00–12:30 | Vibecoding challenge with Andi |
| 14:30–17:00 | Final coding sprint and pitch deck preparation |
| 17:00–18:00 | Pitches and award ceremony |

Each team has five uninterrupted minutes for its demo, followed by a short Q&A. Open with an example from your test.

## Winners and prizes

All teams are ranked together across the three tracks. There is a first, second and third place overall, so two or even all three of them can come from the same track.

| Place | Prize |
|---|---|
| 1st | A Ledger Nano S Plus for each team member |
| 2nd | A purple TUM Blockchain Club hoodie for each team member |
| 3rd | A purple TUM Blockchain Club hoodie for each team member |

The TUM Blockchain Club organises the prizes.

**Working student opportunity:** If we at LIGHT UP really like a team's result, we would like to talk to its members about a working student position with us.

## Use of results

By submitting, you agree that LIGHT UP may use, adapt and publish your submission, for example in its comparisons, on its website and in videos. When LIGHT UP adopts a proposal, it credits the team by its team name.

## Editorial ground rules

- Cite sources, record the test date and distinguish observations, estimates and missing evidence. Keep the weaknesses visible even for the highest-scoring product.
- Use plain language. For German website copy, follow LIGHT UP house style, including "Du" and "Sicherheit".
- Keep the work educational. Exclude price predictions, trading signals, individual coin recommendations, investment advice and paid placements.
- Use public sources, your own hands-on observations, approved extracts or clearly labelled synthetic data. Keep personal information, account data, raw audience records, affiliate revenue, partner contracts and licensing terms out of submissions.

## Organizer checklist

- **LIGHT UP:** Prepare the track introductions with one real example each (Andi presents on site), provide dated matrix extracts and be available to the teams during team work. Explain the affiliate links in the exchange track at the start.
- **TUM Blockchain Club:** Share the submission link and collect each team’s project and pitch deck.
- **Together:** The event language is English. Tell participants at the start which materials will be public and how LIGHT UP uses and credits results.
- **After the event:** LIGHT UP reruns promising tests, takes proposed weighting changes to its community and records which changes are adopted and why.
