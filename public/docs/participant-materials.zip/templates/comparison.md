# Comparison team submission

Team name · Track · Chosen topic · Test date · Matrix version · Category and criteria you worked on · AI tools used

## Proposed change

| Current criterion, points or presentation | Proposed change | Why it helps the reader |
|---|---|---|
| | | |

## Test observations

Record your observations and sources. Explain how to record “feature absent”, “not applicable” and “not verified”.

| Product and version | Evidence and date | Observation | Result | Limitation |
|---|---|---|---|---|
| | | | | |
| | | | | |

## What readers see

Insert the table, graphic, explanation text or mock-up. Can a reader trace a displayed rating back to the observation?

## Maintenance

- Minutes spent on setup and per product during the pilot:
- Estimated effort for a full update and assumptions:
- Update interval or trigger and rationale:
- What a tool could flag and what a person must verify:

## Possible press use

Write the editorial question. Sketch the chart or table and the dated source page a journalist could cite. Specify the sample, coverage and limitations needed to publish the finding.
